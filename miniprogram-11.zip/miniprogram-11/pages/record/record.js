var app = getApp();     // 取得全局App
Page({
  data: {
    radio: '0',
    kecheng:null
  },
  //页面加载时 获取课程名列表
  onLoad: function (options) {
    var that = this;
    console.log(app.globalData.userInfo.id),
    wx.request({
      url: 'http://39.99.240.31/teacher/GetkechengName.php',
      method:'GET',
      data:{
        id: app.globalData.userInfo.id
      },
      success(res){
        console.log(res.data),
        that.setData({
          kecheng:res.data //保存课程数据
        })
      }
    })
  },
  onChange(event) {
    this.setData({
      radio: event.detail
    });
  },
  onClick(event) {
    const { name } = event.currentTarget.dataset;
    this.setData({
      radio: name
    });
  },
  queqing:function(){
    //用等号修改全局的课程编号
    if(this.data.radio=='0'){
      wx.showModal({
        title: '提示',
        content: '请选择课程号',
        showCancel:false,
        success (res) {
          console.log('用户点击确定')
        }
      })
    }
    else{
      app.globalData.kechengqueqing_id = this.data.radio;// 取得全局变量需要的值
      wx.navigateTo({
        url:"/pages/queqing/queqing",
      })
    }
  },
  
  qingjia:function(){
    //用等号修改全局的课程编号
    if(this.data.radio=='0'){
      wx.showModal({
        title: '提示',
        content: '请选择课程号',
        showCancel:false,
        success (res) {
          console.log('用户点击确定')
        }
      })
    }
    else{
      app.globalData.kechengqingjia_id = this.data.radio;// 取得全局变量需要的值
      wx.navigateTo({
        url:"/pages/qingjia/qingjia",
      })
    }
  }
});