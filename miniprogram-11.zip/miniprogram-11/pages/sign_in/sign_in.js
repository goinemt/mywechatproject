Page({
  data: {

  },

  formSubmit: function (e) {
    //测试
    if (e.detail.value.id=="root"){
      wx.switchTab({
        url: '/pages/get_face/get_face',
      })
    }
    if (e.detail.value.id.length == 0 || e.detail.value.psw.length == 0) {
      wx.showToast({
        title: '账户或密码为空！',
        icon: 'loading',
        duration: 1500
      })
      setTimeout(function () {
        wx.hideToast()
      }, 2000)
    } else {
      wx.request({
        url: 'http://39.99.240.31/teacher/wechatlogin.php',
        method: 'GET',
        header: {
          'content-type': 'application/json'
        },
        data: {
          id: e.detail.value.id,
          psw: e.detail.value.psw
        },
        success: function (res) {
          console.log(res);
          console.log("账号：" + res.data.id + "密码：" + res.data.psw);
          console.log("输入账号为：" + e.detail.value.id + "输入密码为：" + e.detail.value.psw);
          if (res.data.id == e.detail.value.id || res.data.psw == e.detail.value.psw)//账号密码正确
          {
            //保存用户的信息
            var app = getApp();     // 取得全局App
            app.globalData.userInfo = res.data;// 取得全局变量需要的值
            console.log(app.globalData.userInfo)
            wx.switchTab({
              url: '/pages/select_ke/select_ke',
            })
          } else {
            wx.showModal({
              title: '登录失败',
              content: '用户名或密码错误',
              showCancel:false,
              success (res) {
                console.log('用户点击确定')
              }
            })
          }
        }
      })
    }
  }
})