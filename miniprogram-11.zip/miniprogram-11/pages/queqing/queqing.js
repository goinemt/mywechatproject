// pages/queqing/queqing.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:"",
    array:[], //计数记录
    queqing:[], //详细记录
    isrecord:false,
    active: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      id: app.globalData.kechengqueqing_id
    })
    var that = this;
    //获取总览记录 array
    wx.request({
      url: 'http://39.99.240.31/teacher/queqing.php',
      method:"POST",
      data:{
        id: that.data.id //课程号
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      }, 
      success(res){
        console.log(res.data);
        that.setData({
          array:res.data
        })
        if(res.data.length==0){
          that.setData({
            isrecord:true
          })
        }
      }
    })
    //获取详细记录 queqing
    wx.request({
      url: 'http://39.99.240.31/teacher/queqing2.php',
      method:"POST",
      data:{
        id: that.data.id //课程号
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      }, 
      success(res){
        console.log(res.data);
        that.setData({
          queqing:res.data
        })
      }
    })
  },
})