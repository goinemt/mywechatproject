// pages/get_face/get_face.js
var app = getApp(); // 取得全局App  
var cnt = 0;  //api返回的次数
var facenum = 0;  //检测到的人脸数目
var res_id = []; // 识别的结果
var fail_id = [];  //由于并发数
Page({
  data: {
    //username:"" 教师姓名
    //src 相机图片目录
    //arr_facetoken 从图片中检测到的face_token数组
    face_num: 0,
    show: false, //控制遮罩层
  },
  /**
   * 加载教师所选需要考勤的课程下 所有学生的信息
   */
  onLoad: function (options) {
    cnt = 0;
    this.setData({ //获取教师名字
      username: app.globalData.userInfo.name
    })
  },
  //上传图片 暂时不需要用到了
  uploadimg: function (e) {
    var that = this;
    wx.chooseImage({
      count: 1,
      success(res) { //选择图片成功
        var tempFilePaths = res.tempFilePaths; //图片临时地址
        wx.uploadFile({
          url: "http://localhost/test/upload.php", //后台上传图片的方法地址
          filePath: tempFilePaths[0], //上传图片的临时地址,
          name: 'file',
          formData: {
            'user': 'test'
          },
          success(res) {
            const data = res.data
            console.log(data);
          }
        })
      }
    })
  },
  /**
   * 人脸识别 返回识别成功的学生学号
   */
  takeface: function () {
    cnt = 0;
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    const ctx = wx.createCameraContext() //创建相机上下文
    var resdetect = null;
    ctx.takePhoto({
      quality: 'high', //获取原图
      success: (res) => {
        this.setData({
          src: res.tempImagePath //得到拍照后的图片地址
        });
        wx.uploadFile({ //上传图片到接口，获取人脸唯一标识face_token
          url: "https://api-cn.faceplusplus.com/facepp/v3/detect",
          filePath: that.data.src, //刚才拍照的图片地址
          //文件对应的 key，开发者在服务端可以通过这个 key 获取文件的二进制内容
          name: 'image_file', //图片的字段名和接口的字段要对应上 
          header: {
            "Content-Type": "multipart/form-data" //必须用此header
          },
          formData: {
            'api_key': '-Bu1QIkQVBNjRwkBYMfOMicVyG8IihCI', //创建的 apikey
            'api_secret': 'i0Y2al-ZdCl3oqVP1e2i9lrkQHl9tiDU', //api_secret
          },
          success(res) {
            var res_detect = JSON.parse(res.data); //将一个 JSON 字符串转换为对象
            //resdetect = res_detect; //保存人脸检测的结果
            console.log("人脸检测完成 检测到的人脸数为 ：" + res_detect.face_num);
            console.log("详细的face_token数组如下");
            console.log(res_detect);
            //保存face_num 
            facenum = res_detect.face_num;
            that.setData({
              face_num: res_detect.face_num
            })

            //如果检测不到人脸
            if (res_detect.face_num == 0) { //根据反回的数据判断是是否检测到人脸
              wx.hideLoading()
              wx.showModal({
                title: '提示',
                content: '检测不到人脸',
                showCancel: false
              })
              return;
            } else { //检测到了人脸
              //检测到人脸了 face_token数组：res_detect.faces[i].face_token
              //console.log("正在进行人脸识别...")
              //app.globalData.res_detect = res_detect;
              that.searchFace(res_detect);
            }
          },
        })
      }
    })
  },
  //人脸识别的QPS上限为3个
  //模块化 克服recall函数异步的问题
  //人脸搜索 传入人脸检测的结果
  searchFace: function (res_detect) {
    //分割face_num[0...9] ..
    console.log("开始进行人脸搜索")
    var index = 0;
    var that = this;
    for (; index < res_detect.face_num; index++) {
      this.search_Face(res_detect.faces[index].face_token)
    }
  },
  //人脸搜索函数 如果搜索到人脸则返回该人脸对应的学号 如果没有则返回0
  //与上一个函数不同的是 需要传入某一个facetoken 是上一个函数的组成部分
  search_Face: function (facetoken) {
    wx.request({
      url: 'https://api-cn.faceplusplus.com/facepp/v3/search', //接口
      method: 'post',
      data: {
        'api_key': '-Bu1QIkQVBNjRwkBYMfOMicVyG8IihCI', //请填写你创建的 apikey
        'api_secret': 'i0Y2al-ZdCl3oqVP1e2i9lrkQHl9tiDU', //请填写你的api_secret
        'face_token': facetoken, //传入face_token和脸集中的数据比对
        'outer_id': 'student', //脸集唯一标识，就是上面我们创建的脸集
        'return_result_count': '1' //返回一条匹配数据，范围1-5
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      success(res) {
        var tmp = cnt+1;
        console.log("第"+tmp+"次 进行人脸搜索")
        console.log(res)
        if(res.statusCode == 403){
          return;
        }
        cnt++;
        var res_search = res.data;
        
        console.log("库中最相似人脸的置信度："+res_search['results'][0]['confidence']) //打印最大人脸的置信度
        if (res.data['results'][0]['confidence'] > 80) { //搜索到人脸 保存人脸识别结果
          res_id.push(res_search['results'][0]['user_id']);
        } 
        if (cnt == facenum) {
          app.globalData.arr_resid = res_id; //保存识别的结果 到APP全局
          wx.hideLoading() 
          wx.showModal({
            title: '提示',
            content: '人脸识别完成',
            showCancel: false,
            success(res) {
              if (res.confirm) {
                wx.navigateTo({
                  url: '/pages/res_kaoqin/res_kaoqin',
                })
              }
            }
          })
        } 
      },
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})