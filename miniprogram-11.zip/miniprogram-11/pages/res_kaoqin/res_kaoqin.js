var app = getApp(); // 取得全局App
Page({
  data: {
    //arr_id 选课学生 学号  
    //arr_name 选课学生姓名
  },
  /**
   * 加载教师所选需要考勤的课程下 所有学生的信息
   */
  onLoad: function(options) {
    this.setData({ //获取教师名字
      username: app.globalData.userInfo.name
    })
    var isdisable = []
    var that = this
    var arrres = [] //考勤的结果 0 代表缺勤 1代表出勤
    var arrname = [] //选课学生姓名
    var arrid = [] //选课学生学号
    var cnt = 0 //缺勤的人数
    var resid = app.globalData.arr_resid //人脸识别的结果
    var rate = 0 //缺勤率
    console.log(resid)
    console.log(app.globalData.kechengkaoqin)
    //获取选课学生id和姓名 
    wx.request({
      url: 'http://39.99.240.31/teacher/getstudetinfo.php',
      method: "post",
      data: {
        id: app.globalData.kechengkaoqin
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res) {
        console.log("已选课学生信息")
        var tmp = res.data
        console.log(res.data)
        for (var i in tmp) {
          arrid.push(tmp[i].stu_id)
          arrname.push(tmp[i].name)
        }
        //核对缺勤学生的信息
        // console.log("核对")
        console.log(arrid)
        console.log(resid)
        //将识别到的人脸与课程信息人脸进行核对
        //考虑代课情况 识别出的人脸不是本课程人脸
        for (var i in arrid) {
          isdisable.push(false)
          if (resid.indexOf(arrid[i]) == -1) { //不存在 缺勤
            arrres.push(0)
            cnt++
          } else arrres.push(1)
        }
        rate = Math.round(cnt * 100 / arrid.length)
        that.setData({
          arr_res: arrres,
          arr_id: arrid,
          arr_name: arrname,
          count: cnt,
          rate: rate,
          isdisable: isdisable
        })
        console.log("缺勤率" + rate + "%")
        console.log(arrres)
        app.globalData.res_bool = arrres
      }
    })

  },

  //点击人工匹配 缺勤=>出勤
  deleteres: function(event) {
    var index = event.currentTarget.dataset.id
    var able = this.data.isdisable
    able[index] = true
    this.data.arr_res[index] = 1
    this.setData({
      isdisable: able
    })
  },

  //上传考勤结果
  myupload: function() {
    console.log(this.data.arr_id)
    console.log(this.data.arr_res) 
    console.log(app.globalData.kechengkaoqin)
    var that = this 
    wx.request({ //上传考勤结果
      url: 'http://39.99.240.31/teacher/reskaoqing.php',
      method: "POST",
      data: {
        id: that.data.arr_id, //课程的所有学生ID
        res: that.data.arr_res , //考勤结果 0 代表缺勤 1代表出勤
        kecheng: app.globalData.kechengkaoqin //考勤的课程ID
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res) {
        console.log(res.data)
        if(res.data.length > 1){
          wx.showToast({
            title: '上传失败',
            icon: 'loading',
            duration: 2000
          })
        }
        else{
          wx.showModal({
            title: '上传成功',
            content: '是否返回主界面',
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
                wx.switchTab({
                  url: '/pages/select_ke/select_ke',
                })
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      }
    })

    
  }
})