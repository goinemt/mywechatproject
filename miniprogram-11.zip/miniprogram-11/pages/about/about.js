var app = getApp();
Page({
  data: {
    value: '',
    id: '', 
  },
  onLoad: function (options) {
    this.setData({
      id: app.globalData.userInfo.id //教师编号 
    })
  },
  onChange(event) {
    // event.detail 为当前输入的值
    this.setData({
      newpsw: event.detail,
    })
  },
  setpsw:function(){
    console.log(this.data.newpsw)
    var psw = this.data.newpsw
    if(psw.length<6){
      wx.showModal({
        title: '提示',
        content: '密码长度应该大于6个字符',
        showCancel:false,
        success (res) {
          console.log('用户点击确定')
        }
      })
      return;
    }
    //修改密码
    //请求写入请假数据
    wx.request({
      url: 'http://39.99.240.31/teacher/setpsw.php',
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      }, 
      data: {
        psw: psw,
        sid: this.data.id,
      },
      success: function (res) {
        console.log(res.data);
        if(res.data == 0){
          wx.showModal({
            title: '修改成功',
            content: '新密码已经保存',
            showCancel:false,
            success (res) {
              console.log('用户点击确定')
            }
          })
        }else {
          wx.showModal({
            title: '修改失败',
            content: '可能是数据重复提交',
            showCancel:false,
            success (res) {
              console.log('用户点击确定')
            }
          })
        }
      }
    })
  }
});