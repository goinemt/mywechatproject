var app = getApp(); // 取得全局App
Page({
  data: {
    radio: '0',
    kecheng: null
  },
  onLoad: function(options) {
    var that = this;
    wx.request({
      url: 'http://39.99.240.31/teacher/GetkechengName.php',
      //url: 'http://localhost/test/GetkechengName.php',
      method: 'GET',
      data: {
        id: app.globalData.userInfo.id //教师编号
      },
      success(res) {
        console.log(res.data),
          that.setData({
            kecheng: res.data //保存课程数据
          })
      }
    })
  },
  onChange(event) {
    this.setData({
      radio: event.detail
    });
  },
  onClick(event) {
    const {
      name
    } = event.currentTarget.dataset;
    this.setData({
      radio: name
    });
  },
  takephoto: function() {
    //用等号修改全局的课程编号
    if (this.data.radio == '0') {
      wx.showToast({
        title: '请选择相应课程！',
        icon: 'none',
        duration: 1500
      })
    } else {
      app.globalData.kechengkaoqin = this.data.radio; // 取得全局变量需要的值
      console.log("教师考勤课程号为："+this.data.radio)
      wx.navigateTo({
        url: "/pages/get_face/get_face",
      })
    }
  }
});